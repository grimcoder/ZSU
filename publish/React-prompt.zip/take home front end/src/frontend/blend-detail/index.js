// get blend API is at /api/v1/blends/:id
const BlendDetail = () => {
  return (
    <div>
      <h2>Blend Detail Page</h2>
    </div>
  );
};

export default BlendDetail;
