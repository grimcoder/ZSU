export default [
  {
    id: 0,
    name: 'Tasty Blend',
    blends: [],
    spices: [1, 5, 35, 52],
    description: 'This is a new spice blend',
  },
  {
    id: 1,
    name: 'Blendy Blend',
    blends: [0],
    spices: [2, 6, 37, 246],
    description: 'This is a new spice blend',
  },
  {
    id: 2,
    name: 'Meta Blend',
    blends: [0, 1],
    spices: [400, 401, 402, 403],
    description: 'This is a new spice blend',
  }
];
